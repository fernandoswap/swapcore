//
//  SwapCore.h
//  SwapCore
//
//  Created by Fernando Cruz on 05/02/25.
//

#import <Foundation/Foundation.h>

//! Project version number for SwapCore.
FOUNDATION_EXPORT double SwapCoreVersionNumber;

//! Project version string for SwapCore.
FOUNDATION_EXPORT const unsigned char SwapCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwapCore/PublicHeader.h>


